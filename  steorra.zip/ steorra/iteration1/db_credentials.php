<?php

define("DB_server","localhost");
define("DB_user","root");
define("DB_password","");
define("DB_name","phpmyadmin");


?>